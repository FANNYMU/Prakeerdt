const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const data = require("../data.json");

app.use(bodyParser.json());

// Endpoint untuk melakukan pencarian produk
app.get("/api/products/search", (req, res) => {
  const query = req.query.q.toLowerCase();
  const searchResults = data.filter(
    (product) =>
      product.name.toLowerCase().includes(query) ||
      product.description.toLowerCase().includes(query)
  );
  res.json(searchResults);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server berjalan di port ${PORT}`);
});
